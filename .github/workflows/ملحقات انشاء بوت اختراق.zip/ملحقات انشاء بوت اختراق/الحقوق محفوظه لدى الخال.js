الحقوق محفوظه لدى قناة الخال ALOUSH 👇👇
t.me/Driving_uncle_personally
t.me/Driving_uncle_personally

الموقع الاول المستخدم ب الشرح 👇
github.com

الموقع الثاني المستخدم ب الشرح 👇
render.com

بوت فاذر لإنشاء بوت 👇
t.me/BotFather
بوت استخراج الايدي 👇
t.me/Resysg_bot

رابط مباشر لتحميل تطبيق امتي منجر 👇
t.me/Driving_uncle_personally/4484

الخال ALOUSH
@TT1TT6